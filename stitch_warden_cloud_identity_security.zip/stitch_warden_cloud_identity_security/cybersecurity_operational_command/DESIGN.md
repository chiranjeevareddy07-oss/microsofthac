---
name: Cybersecurity Operational Command
colors:
  surface: '#10141a'
  surface-dim: '#10141a'
  surface-bright: '#353940'
  surface-container-lowest: '#0a0e14'
  surface-container-low: '#181c22'
  surface-container: '#1c2026'
  surface-container-high: '#262a31'
  surface-container-highest: '#31353c'
  on-surface: '#dfe2eb'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dfe2eb'
  inverse-on-surface: '#2d3137'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#fff3f2'
  on-tertiary: '#68000a'
  tertiary-container: '#ffceca'
  on-tertiary-container: '#ba1b24'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#10141a'
  on-background: '#dfe2eb'
  surface-variant: '#31353c'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  code-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-lg: 1rem
  margin: 1rem
  margin-lg: 1.5rem
  space-xs: 0.125rem
  space-sm: 0.25rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
---

## Brand & Style
The design system projects mission-critical authority, hyper-precision, and continuous vigilance. Engineered for Security Operations Center (SOC) engineers, DevSecOps teams, and Cloud Identity architects, the interface eliminates decorative noise in favor of high-density clarity, deterministic visual cues, and instant threat comprehension.

The aesthetic fuses modern high-performance SaaS engineering with a tactical SOC telemetry console. Visual density is balanced by rigid structural alignment, micro-borders, and targeted luminosity. Depth is not communicated via soft organic shadows, but rather through surface elevation stepped in deep slate values and punctuated by sharp electric cyan conduits. Every interactive element signifies operational readiness: high-urgency states demand immediate recognition via saturated, non-diffuse signaling, while baseline monitoring remains stable, low-strain, and dark.

## Colors
The palette is calibrated strictly for high-contrast dark environments. The visual canvas stays grounded in near-black slate to prevent eye fatigue during sustained incident response, while high-chroma signals are reserved for active telemetry and state mutations.

### Functional Palette
- **Canvas Base (`#0a0e14`)**: The foundational canvas plane. Non-reflective, deep obsidian slate.
- **Surface Elevation 1 (`#111722`)**: Structural cards, tables, and panel groupings.
- **Surface Elevation 2 (`#182030`)**: Hover states, active row states, and interactive containers.
- **Surface Accent / Overlays (`#1e293b`)**: Structural framing, divider rules, and low-contrast borders.
- **Primary Accent (`#00f0ff`)**: Focal guidance, active selections, focus rings, and real-time trace telemetry.
- **Telemetry Safe (`#10b981`)**: Verified posture, active zero-trust integrity, healthy credentials.
- **Telemetry Warning (`#f59e0b`)**: Dormant accounts, expiring secrets, privilege drift, anomalous volume.
- **Telemetry Critical (`#ef4444`)**: Compromised credentials, immediate policy breaches, active exfiltration alerts.

### Typographic Contrast
- **Text Dominant (`#f8fafc`)**: Incident titles, critical metrics, column headers.
- **Text Body (`#94a3b8`)**: Machine summaries, descriptions, policy logic.
- **Text Subdued (`#64748b`)**: Timestamps, ARN prefixes, table metadata, structural separators.

## Typography
The system enforces a dual-typeface model. **Inter** handles high-level cognitive hierarchy—page headers, metrics labels, dialogue prompts, and structural UI elements. It provides clean, neutral legibility at compact sizes without drawing unneeded attention.

**JetBrains Mono** serves as the authoritative engine for all operational data. Service account identifiers, AWS ARNs, public key fingerprints, SHA-256 digests, IP addresses, Unix timestamps, and JSON-based IAM permissions must render strictly in JetBrains Mono. Monospaced tabular alignment guarantees vertical scanning efficiency across tabular rows without horizontal tracking jitter.

## Layout & Spacing
Designed around extreme operational density. The rhythm follows a modular 4px coordinate base where vertical space is preserved to keep high-value telemetry above the fold. 

### Grid & Composition
- **Desktop (1440px+)**: 12-column fluid grid with `0.75rem` (12px) gutters and `1rem` outer canvas padding. Density accommodates 3-column split monitoring (Identity Tree / Event Stream / Forensic Inspector).
- **Tablet / Small Console (1024px - 1439px)**: 8-column layout. Sidebars collapse to icon strips; forensic panels transition into overlay drawers.
- **Mobile / On-Call Incident View (<1023px)**: Single column fluid layout with persistent top-level incident triage status bars and stacked data attributes.

Standard table rows are constrained to 36px heights for compact mode and 44px for default mode, preventing excessive vertical scrolling across enterprise identity inventories containing tens of thousands of entities.

## Elevation & Depth
Depth is constructed through physical surface stepping and hard light contrast rather than heavy atmospheric dropshadows. In a dark SOC environment, diffuse blurred drop-shadows create mud and visual clutter; this design system replaces them with structural layer stepping and calibrated luminance borders.

### Surface Hierarchy
1. **Base Ground (`#0a0e14`)**: Root level; background for main canvas views.
2. **Sub-Panel Layer (`#111722`)**: Standard card containers, table backgrounds, and side rails. Framed by a solid 1px border (`#1e293b`).
3. **Elevated Flyout (`#182030`)**: Popovers, command palettes, context menus, and sticky table heads. Uses a 1px border (`#334155`).

### Luminous Depth & High-Risk Accents
- **Normal Cards**: 1px solid border in `#1e293b`. No dropshadow.
- **Telemetry Glow (Focal / Receipt Cards)**: 1px border colored with `#00f0ff` at 40% alpha, backed by an outer glow box-shadow: `0 0 12px -2px rgba(0, 240, 255, 0.15)`.
- **Critical Breach State**: 1px border colored with `#ef4444` at 60% alpha, coupled with an interior glow: `inset 0 0 12px rgba(239, 68, 68, 0.08)`.

## Shapes
Geometry is utilitarian, industrial, and restrained. Structural elements favor micro-radii to maintain an uncompromisingly professional, technical character.

- **Base Radius (0.25rem / 4px)**: Buttons, inputs, inline badges, table rows, and status tags. Sharp enough to feel architectural and dense, with edge softness that prevents visual strain.
- **Container Radius (0.375rem / 6px)**: Forensic panels, memory receipt cards, modal overlays.
- **Indicator Radius (9999px)**: Reserved strictly for micro-status indicators (telemetry dots) and binary toggle capsules.

## Components

### Action Buttons
- **Primary / Authoritative (`Investigate`, `Confirm`)**: Background `#00f0ff`, text `#0a0e14` (Inter 13px SemiBold). Hover triggers full-chroma opacity shift with light cyan border glow.
- **Destructive Fast-Action (`Quarantine`, `Revoke Token`)**: Background `#1c131d`, border 1px solid `#ef4444`, text `#fca5a5`. Hover shifts background to `#ef4444`, text to `#ffffff`.
- **Ghost / Neutral (`Inspect`, `Export`)**: Background transparent, border 1px solid `#1e293b`, text `#94a3b8`. Hover shifts background to `#182030`, border to `#334155`, text to `#f8fafc`.

### SOC Monospace Data Tables
- Header cells: Monospace uppercase label (`label-caps`), color `#64748b`, separated by a 1px border `#1e293b`.
- Data rows: Alternate row highlighting (`#111722` to `#0d121a`). Text runs in `code-md` for machine IDs and `body-md` for descriptions.
- Row States: Hover renders an inner 1px border of `#00f0ff` at 20% opacity and sets background to `#182030`.

### Memory Receipt Cards
- Enclosed identity telemetry containers detailing token generation metadata, hash validations, and parent process trees.
- Visual frame: Background `#111722`, border 1px solid `rgba(0, 240, 255, 0.3)`, with an upper horizontal line accent in `#00f0ff`.
- Header section displays timestamp and verifiable SHA-256 hash in `code-sm` text (`#64748b`).

### Status Indicators & Pulse Nodes
- Structural representation: 6px circular dot paired with a concentric 12px ring.
- Normal: Dot `#10b981`, ring static transparent.
- Active Telemetry / Live Stream: Dot `#00f0ff`, outer ring pulsing via CSS keyframe animation from scale 1.0 to 1.8 with fading opacity.
- Critical Threat: Dot `#ef4444`, outer ring sharp, pulsing at 1.2s intervals in `#ef4444` at 40% alpha.

### Risk & Identity Chips
- Ultra-compact padding: 2px 6px. Font: `label-caps`. Border radius: 2px.
- **High Risk**: Border `rgba(239, 68, 68, 0.4)`, background `rgba(239, 68, 68, 0.1)`, text `#f87171`.
- **Dormant**: Border `rgba(245, 158, 11, 0.4)`, background `rgba(245, 158, 11, 0.1)`, text `#fbbf24`.
- **Machine Entity Type (OAuth / Bot / Service ARN)**: Border `#1e293b`, background `#182030`, text `#94a3b8`.

### Input & Query Terminals
- Search fields and filter terminals are styled as command-line prompts. Left-padded with an electric cyan cursor glyph (`>`).
- Background `#0a0e14`, border 1px solid `#1e293b`, active focus state transitions to border 1px solid `#00f0ff` with zero outline-offset. Typography is locked to `code-md`.